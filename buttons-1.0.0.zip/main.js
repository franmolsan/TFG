var buttonManager = require("buttons");
var http = require("http");
var url = "http://192.168.1.127:3000/button-click";

buttonManager.on("buttonSingleOrDoubleClickOrHold", function(obj) {
	var button = buttonManager.getButton(obj.bdaddr);
	var clickType = obj.isSingleClick ? "click" : obj.isDoubleClick ? "double_click" : "hold";
	
	http.makeRequest({
		url: url,
		method: "POST",
		headers: {"Content-Type": "application/json"},
		content: JSON.stringify({"serialNumber": button.serialNumber, "clickType": clickType}),		
	}, function(err, res) {
		console.log("request status: " + res.statusCode);
	});
});

console.log("Started");