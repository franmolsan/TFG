const httpsRequest = require("./httpsRequest")

async function fetchRooms(){
    
    // fetch the game rooms from the game API
    var host = 'e5bg757f0e.execute-api.eu-west-1.amazonaws.com';
    var path = '/dev/get-game-rooms'
    var ROOMS = await httpsRequest.Get(host,path);
    
    return ROOMS;
}

async function fetchGamestate(){
    
    var host = 'e5bg757f0e.execute-api.eu-west-1.amazonaws.com';
    var path = '/dev/get-gamestate/GameID1'
    const gameState = await httpsRequest.Get(host,path);
    return gameState;
}

async function saveGamestate(handlerInput){
    
    const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
    
    const gameState = {
        "inventory" : sessionAttributes.gamestate.inventory,
        "blockedRooms": sessionAttributes.gamestate.blockedRooms,
        "currentRoom": sessionAttributes.gamestate.currentRoom,
        "GameID": "GameID1"
    }
    
    console.log("SAVING GAMESTATE : " + JSON.stringify(gameState))
    
    // fetch the game rooms from the game API
    var host = 'e5bg757f0e.execute-api.eu-west-1.amazonaws.com';
    var path = '/dev/save-gamestate'
    var response = await httpsRequest.Post(host,path,gameState);
    
    return response;
}

module.exports = { 
    fetchRooms: fetchRooms,
    fetchGamestate: fetchGamestate,
    saveGamestate: saveGamestate
}