// This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
// Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
// session persistence, api calls, and more.
const Alexa = require('ask-sdk-core');
const persistenceAdapter = require('ask-sdk-s3-persistence-adapter');
const httpsRequest = require("./httpsRequest")
const sync = require("./sync")

/*
    setQuestion function
    Useful to set a context for a question
*/
function setQuestion(handlerInput, questionAsked) {
  const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
  sessionAttributes.questionAsked = questionAsked;
  handlerInput.attributesManager.setSessionAttributes(sessionAttributes);
    
}

/*
    setItem function
    sets the current item in the sessionAttributes
*/
function setItem(handlerInput, item) {
  const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
  sessionAttributes.currentItem = item;
  handlerInput.attributesManager.setSessionAttributes(sessionAttributes);
  console.log("currentItem : " + JSON.stringify(sessionAttributes.currentItem));
}

/*
    searchRoom function
    Looks for a room in the ROOMS Object and returns it
    Can also return null if the room hasn't been found
*/
function searchRoom (handlerInput, roomName) {
    
    const ROOMS =  handlerInput.attributesManager.getSessionAttributes().ROOMS;
    
    var roomSearched = null;
    
    // check each room in ROOMS Object
    Object.keys(ROOMS).forEach(function(key,index) {
        // key: the name of the object key
        // index: the ordinal position of the key within the object 
    
        if (ROOMS[key].name == roomName){
        	roomSearched = ROOMS[key]
        }
       
    });
    
    return roomSearched;
}

/*
    setRoom function
    Sets current room in sessionAttributes
*/
function setRoom(handlerInput, room) {
  const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
  sessionAttributes.gamestate.currentRoom = room
  sessionAttributes.hasChangedGamestate = true;
  handlerInput.attributesManager.setSessionAttributes(sessionAttributes);
    
}


/*
    canGoToRoom function
    Checks whether the player can access a room or not, based on the doors in the current room
*/
function canGoToRoom(handlerInput, room){
    const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
    
    // get the doors in the currentRoom
    const currentRoomDoors = sessionAttributes.gamestate.currentRoom.doors
    
    var canGo = false;
   
    // try to find a door to the room we want to go
    // if we find a door, we can go to the room
    // if we don't find a door, we can't go
    if (currentRoomDoors.find(e => (e === room.name))){
        canGo = true
    }
    
    return canGo;
}

function CanAskYesNo (intentName) {
    return IntentsCanAskYesNo.includes(intentName)
}

function isInInventory (inventory, object){
    if (inventory.find(element => element.name === object.name) === undefined) return false;
    else return true;
}

function listItemsInObject(handlerInput, object){
    
    const inventory = handlerInput.attributesManager.getSessionAttributes().gamestate.inventory;
    
    var output = "";
    // check each element of the object
    Object.keys(object).forEach(function(key,index) {
        // key: the name of the object key
        // index: the ordinal position of the key within the object 
    
    
        console.log("inventory: " + JSON.stringify(inventory));
        console.log ("item checked " + JSON.stringify(object[key]))
        // only process the item if it's not in the inventory
        console.log ("find : " + isInInventory(inventory,object[key]))
        
        if (!isInInventory(inventory,object[key])){
            output += object[key].undefinedString
        
            if (index === Object.keys(object).length - 2){
            	 output += " y "
            }
            
            else if (index === Object.keys(object).length - 1){
                output += ". "
            }
            
            else {
                output += ", "
            }
        }

       
    });
    
    console.log("output list items in object " + output)
    return output;
}


function describeRoomElements(room){
    
    var descOutput = "";
    
    if (room.name === "sala 1"){
        
        // output table
        descOutput += "En el centro de la habitación hay una mesa. ";
        descOutput += "Puedes ver que sobre la mesa hay varios objetos. ";
        
        
        // output  sofa
        descOutput += "Al lado de la mesa hay un sofá. ";
                        
        // output shelf
        descOutput += "En una esquina de la habitación hay una estantería llena de libros. "
        
    }
    
    else if (room.name === "sala 2"){
        
    }
    
    else if (room.name === "sala 3"){
        
    }
    
    else if (room.name === "sala 4"){
        
    }
    
    else {
        descOutput += "No hay ningún objeto interesante en la sala."
    }
    
    return descOutput;
}

/*
    getItemInPlace function
    Looks for a room in the ROOMS Object and returns it
    Can also return null if the room hasn't been found
*/
function getItemInPlace (place,itemName) {
    
    const elements = place.elements;
    
    // check each room in ROOMS Object
    const keys = Object.keys(elements);
    
    var itemFound = null;
    var i = 0;
    while (i < keys.length && itemFound === null){
        var key = keys[i]

        if (elements[key].name == itemName){
        	itemFound = elements[key];
        }
        else if (elements[key].hasOwnProperty('elements')){
            itemFound = getItemInPlace(elements[key], itemName)
        }
        i++;
    }
    
    return itemFound;
    
}


/*
    LaunchRequestHandler
    Greets the user when they open the skill
*/
const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    handle(handlerInput) {
        const speakOutput = strings.OPEN_MESSAGE
        
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};


/*
    NewPlayerStartIntentHandler
    Sets everything up for the devices test
*/
const NewPlayerStartIntentHandler = {
    
    // can handle only if StartIntent and has not played before
    canHandle(handlerInput) {

        const attributesManager = handlerInput.attributesManager;
        const sessionAttributes = attributesManager.getSessionAttributes() || {};

        const hasPlayedBefore = sessionAttributes.hasOwnProperty('hasPlayedBefore') ? sessionAttributes.hasPlayedBefore : false;

        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest' && 
        Alexa.getIntentName(handlerInput.requestEnvelope) === 'StartIntent' && !hasPlayedBefore;
    },
    async handle(handlerInput) {


        // read qr data
        var host = 'e5bg757f0e.execute-api.eu-west-1.amazonaws.com';
        var path = '/dev/get-qr-read/qrID1';
        var response = await httpsRequest.Get(host,path);
        var qrTimesRead = response.TimesRead;
        
        
        // read button data 
        path = '/dev/get-button-clicks/2d323b701c2147e6ba38804429720c85'
        response = await httpsRequest.Get(host,path);
        var buttonTimesClicked = response.click;
        var buttonTimesDoubleClicked = response.double_click;
        var buttonTimesHeld = response.hold;
        
        // initialize sessionAttributes with read data
        const sessionAttributes = {
            "buttonTimesClicked": buttonTimesClicked,
            "buttonTimesDoubleClicked":buttonTimesDoubleClicked,
            "buttonTimesHeld":buttonTimesHeld,
            "qrTimesRead":qrTimesRead,
            "hasCheckedButtons": false,
            "hasCheckedQR": false,
            "hasPlayedBefore":true,
            "questionAsked": null,
        }
        
        // save sessionAttributes as persistent
        handlerInput.attributesManager.setPersistentAttributes(sessionAttributes);
        await handlerInput.attributesManager.savePersistentAttributes(); 
    
        // save sessionAttributes for this sesion too
        handlerInput.attributesManager.setSessionAttributes(sessionAttributes);
        
        // set initialRoom
        const initialRoom = searchRoom(handlerInput,'sala inicial')
        setRoom(handlerInput, initialRoom)
        
        // speech
        const speakOutput = strings.FIRST_TIME_START_MESSAGE
        const repromptText = strings.FIRST_TIME_REPROMPT_MESSAGE

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(repromptText)
            .getResponse();
    }
};

/*
    NewPlayerStartIntentHandler
    Welcomes users
*/
const NotNewPlayerStartIntentHandler = {
    
    // can handle only if StartIntent and has played before
    canHandle(handlerInput) {

        const attributesManager = handlerInput.attributesManager;
        const sessionAttributes = attributesManager.getSessionAttributes() || {};

        const hasPlayedBefore = sessionAttributes.hasOwnProperty('hasPlayedBefore') ? sessionAttributes.hasPlayedBefore : false;
        
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest' && 
        Alexa.getIntentName(handlerInput.requestEnvelope) === 'StartIntent' && hasPlayedBefore;
    },
    handle(handlerInput) {

        const speakOutput = strings.DEFAULT_START_MESSAGE

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

/*
    YesIntentHandler
    Will respond differently depending on the question asked before
    The question asked is saved in the sessionAttributes
*/
const YesIntentHandler = {
    
    // can always handle if the intent is YesIntent
    canHandle(handlerInput) {
        
        const attributesManager = handlerInput.attributesManager;
        const sessionAttributes = attributesManager.getSessionAttributes();
        
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.YesIntent';
    },
    handle(handlerInput) {
        
        // get question
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes()
        const question = sessionAttributes.questionAsked;
        var speakOutput = "";
        
        // clear question in sessionAttributes
        // to avoid any possible mishandlings 
        setQuestion(handlerInput, null);
        
        // change output speech depending on the question
        if (question === 'HasEntendidoInstrucciones'){
            speakOutput += ' Perfecto. Si en algún momento deseas recordar las instrucciones, pídemelo. ';
        }
        
        else if (question === 'QuieresGuardarItem'){
            
            const item = sessionAttributes.currentItem;
            
            var inventory = sessionAttributes.gamestate.inventory;
            inventory.push(item)
            
            sessionAttributes.gamestate.inventory = inventory;
            sessionAttributes.hasChangedGamestate = true;
            handlerInput.attributesManager.setSessionAttributes(sessionAttributes);
            
            // set item to null in sessionAttributes
            setItem(handlerInput,null);
            
            speakOutput += ' Perfecto. Has guardado ' + item.definedString + ' en el inventario. ';
        }
        
        else if (question === 'QuieresUsarItem'){
            
            const sessionAttributes = handlerInput.attributesManager.getSessionAttributes()
            const item = sessionAttributes.currentItem;
            
            // set item to null in sessionAttributes
            setItem(handlerInput,null);
            
            speakOutput += ' TODO: Registrar uso de ' + item.definedString + '. ';
        }
        
        // no question was asked
        else {
            speakOutput += strings.YES_NO_ERROR_MESSAGE
        }

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
}


/*
    NoIntentHandler
    Will respond differently depending on the question asked before
    The question asked is saved in the sessionAttributes
*/
const NoIntentHandler = {
    
    // can always handle if the intent is NoIntent
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.NoIntent' ;
    },
    handle(handlerInput) {
        
        // get question
        const question = handlerInput.attributesManager.getSessionAttributes().questionAsked;
        var speakOutput = "";
        
        // clear question in sessionAttributes
        // to avoid any possible mishandlings 
        setQuestion(handlerInput, null);
        
        // change output speech depending on the question
        if (question === "HasEntendidoInstrucciones"){ 
            speakOutput += 'Te repito las instrucciones: ' + strings.INSTRUCTIONS_MESSAGE;
            
            // the Instructions message ends in a question, so we need to set it
            // to chain the question until the user understands it (answer with a 'yes')
            setQuestion(handlerInput, 'HasEntendidoInstrucciones');
        }
        
        else if (question === 'QuieresGuardarItem'){
            
            const sessionAttributes = handlerInput.attributesManager.getSessionAttributes()
            const item = sessionAttributes.currentItem;
            
            speakOutput += ' No has guardado ' + item.definedString + '. ';
            
            // set item to null in sessionAttributes
            setItem(handlerInput,null);
        }
        
        else if (question === 'QuieresUsarItem'){
            
            const sessionAttributes = handlerInput.attributesManager.getSessionAttributes()
            const item = sessionAttributes.currentItem;
            
            speakOutput += ' No has usado ' + item.definedString + '. ';
            
                        
            // set item to null in sessionAttributes
            setItem(handlerInput,null);
        }
        
        
        // no question was asked
        else {
            speakOutput += strings.YES_NO_ERROR_MESSAGE
        }
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
}


/*
    DevicesCheckIntentHandler
    Test to make sure that everything is running smoothly 
    (devices are connected and API is operational)
*/
const DevicesCheckIntentHandler = {

    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'DevicesCheckIntent';
    },

    async handle(handlerInput) {
        
        var speakOutput = "";
        
        // read sessionAttributes
        const attributesManager = handlerInput.attributesManager;
        const sessionAttributes = attributesManager.getSessionAttributes() || {};
        var host = 'e5bg757f0e.execute-api.eu-west-1.amazonaws.com';
        
        // if qr system has not been checked yet
        if (!sessionAttributes.hasCheckedQR){
            var path = '/dev/get-qr-read/qrID1';
            
            // make http request
            const response = await httpsRequest.Get(host,path);
            
            // if the qr has been read, mark it as checked
            if (response.TimesRead > sessionAttributes.qrTimesRead){
                sessionAttributes.hasCheckedQR = true;
                attributesManager.setSessionAttributes(sessionAttributes);
                speakOutput += " Se ha leído el código QR correctamente. ";
            }
            
            else {
                speakOutput += " No se ha leído el código QR. ";
            }
        }
        
        
        // if buttons have not been checked yet
        if (!sessionAttributes.hasCheckedButtons){
            path = '/dev/get-button-clicks/2d323b701c2147e6ba38804429720c85';
            
            // make http request 
            const response = await httpsRequest.Get(host,path);
            
            // calculate how many clicks have been made
            const timesClicked = response.click - sessionAttributes.buttonTimesClicked
            const timesDoubleClicked = response.double_click - sessionAttributes.buttonTimesDoubleClicked
            const timesHeld = response.hold - sessionAttributes.buttonTimesHeld
                
            // check standard clicks
            if (timesClicked >= 1){
                speakOutput += "Has hecho " + timesClicked
                if (timesClicked > 1) speakOutput +=" clicks del botón. ";
                else speakOutput +=" click del botón. ";
               
            }
            else {
                speakOutput += " Debes hacer un click estándar del botón.";
            }
            
            // check double clicks
            if (timesDoubleClicked >= 1){
                speakOutput += "Has hecho " + timesDoubleClicked
                if (timesDoubleClicked > 1) speakOutput +=" doble clicks del botón. ";
                else speakOutput +=" doble click del botón. ";
            }
            
            else {
                speakOutput += " Debes hacer un doble click del botón.";
            }
            
            // check long clicks (hold)
            if (timesHeld >= 1){
                speakOutput += "Has mantenido el botón pulsado " + timesHeld
                if (timesHeld > 1) speakOutput +=" veces. ";
                else speakOutput +=" vez. ";
                
            }
            else {
                speakOutput += " Debes realizar una pulsación larga del botón. ";
            }
            
            // if every type of click has been registered,
            // mark buttons as checked
            if (timesClicked >= 1 && timesDoubleClicked >= 1 && timesHeld >= 1){
                speakOutput += " Los botones se han probado correctamente. ";
                sessionAttributes.hasCheckedButtons = true;
                attributesManager.setSessionAttributes(sessionAttributes);
            }
        }
        
        // speech to say whether the test has finished or not
        if (sessionAttributes.hasCheckedQR && sessionAttributes.hasCheckedButtons){
            speakOutput += " Se ha terminado la prueba con éxito. ";
        }
        else {
            speakOutput += " Todavía no ha terminado la prueba. Cuando hayas comprobado todo, vuelve a pedirme que realice la prueba.";
        }
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

/*
    InstructionsIntentHandler
    Outputs a message with the game instructions (controls)
*/
const InstructionsIntentHandler = {
    
     canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'InstructionsIntent';
    },
    
    handle(handlerInput) {
        
        // set question asked 
        setQuestion(handlerInput,'HasEntendidoInstrucciones');
        
        // say the instructions
        const speakOutput = strings.INSTRUCTIONS_MESSAGE;
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
}



/*
    GoToIntentHandler
    Moves the player to the place they want
*/
const GoToIntentHandler = {
    
     canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'GoToIntent';
    },
    
    handle(handlerInput) {
        const attributesManager = handlerInput.attributesManager;
        const sessionAttributes = attributesManager.getSessionAttributes()
        
        var speakOutput = "";
        
        // get the roomName from the intent slots
        const roomName = new String (handlerInput.requestEnvelope.request.intent.slots.room.resolutions.resolutionsPerAuthority[0].values[0].value.name);
        
        // search the room in the ROOMS object
        const room = searchRoom(handlerInput, roomName);
        
        // if the room has been found 
        if (room !== null){
            
            // check if the player is already there
            if(room.name === sessionAttributes.gamestate.currentRoom.name) {
                speakOutput += strings.YOU_ARE_ALREADY_THERE_MESSAGE + " " + room.string + ". ";
            }
            
            // if the player is not there, check if they can go
            else if(canGoToRoom(handlerInput, room)){
                
                // if they can, set the room in the game state
                setRoom(handlerInput,room)
                speakOutput += strings.GO_TO_OK_MESSAGE + " " + room.string + ". ";
            }
            
            // if they can't go, tell them
            else {
                speakOutput += strings.GO_TO_ERROR_MESSAGE + " " + room.string + ". ";
            }
        }
        
        // the room hasn't been found in the ROOMS object
        else {
           speakOutput += strings.ROOM_NOT_FOUND_MESSAGE;
        }

        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
}

/*
    WhereAmIIntentHandler
    Tells the player where they are
*/
const WhereAmIIntentHandler = {
    
     canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhereAmIIntent';
    },
    
    handle(handlerInput) {
        
        const attributesManager = handlerInput.attributesManager;
        const sessionAttributes = attributesManager.getSessionAttributes()
        
        // get the currentRoom from the sessionAttributes
        const room = sessionAttributes.gamestate.currentRoom
        
        // output the currentRoom
        var speakOutput = strings.WHERE_IS_MESSAGE + room.string
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
}

/*
    WhereCanIGoIntentHandler
    Tells the player where can they go
*/
const WhereCanIGoIntentHandler = {
    
     canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhereCanIGoIntent';
    },
    
    handle(handlerInput) {
        
        const attributesManager = handlerInput.attributesManager;
        const sessionAttributes = attributesManager.getSessionAttributes()
        
        // get the doors in the currentRoom
        const doors = sessionAttributes.gamestate.currentRoom.doors
        
        // output all the rooms the player can go to
        var speakOutput = strings.CAN_GO_TO_MESSAGE
        
        doors.forEach((item, index) => {
            speakOutput += item;
            
            if (index === doors.length - 2){
                speakOutput += " y "
            }
            else if (index === doors.length - 1){
                speakOutput += " . "
            }
            else {
                speakOutput += " , "
            }
        });
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
}

/*
    RoomDescriptionIntentHandler
    Describes the room where the player is.
*/
const RoomDescriptionIntentHandler = {
    
     canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'RoomDescriptionIntent';
    },
    
    handle(handlerInput) {
        
        const attributesManager = handlerInput.attributesManager;
        const sessionAttributes = attributesManager.getSessionAttributes()
        
        // get the currentRoom from the sessionAttributes
        const room = sessionAttributes.gamestate.currentRoom
        
        // output the currentRoom
        var speakOutput = strings.WHERE_IS_MESSAGE + room.string + ". " 
        
        speakOutput += describeRoomElements(room)
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
}


/*
    CheckItemIntentHandler
    Describes the room where the player is.
*/
const CheckItemIntentHandler = {
    
     canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'CheckItemIntent';
    },
    
    handle(handlerInput) {
        
        const attributesManager = handlerInput.attributesManager;
        const sessionAttributes = attributesManager.getSessionAttributes()
        const currentRoom = sessionAttributes.gamestate.currentRoom;
        const inventory = sessionAttributes.gamestate.inventory;
        
        // get the item from the intent slots
        const itemName = new String (handlerInput.requestEnvelope.request.intent.slots.item.resolutions.resolutionsPerAuthority[0].values[0].value.name);
        
        var speakOutput = "";
        
        var item = getItemInPlace(currentRoom,itemName)
        
        console.log ("Found item " + JSON.stringify(item))
        
            
        if (isInInventory(inventory,item)){
            item = null
        }
        
        if (item !== null){

            // output item description
            speakOutput += item.desc;
            
            // output elements inside the item
            if (item.elements !== null && item.elements !== undefined){
                
                // list elements in the item
                var itemsInObjectOutput = listItemsInObject(handlerInput,item.elements);
                
                if (itemsInObjectOutput !== ""){
                    speakOutput += "En " + item.definedString + " hay " + itemsInObjectOutput;
                }
                
            }
            
            // if it can be picked, ask the player if they want to save it.
            if (item.canBePicked === true){
                            
                // set item in sessionAttributes
                setItem(handlerInput,item);
                speakOutput += "¿Quieres guardar " + item.definedString +  " en el inventario? "
                setQuestion(handlerInput,'QuieresGuardarItem')
            }
            
            // if it can be used, ask the player if they want to use it
            else if (item.canBeUsed === true){
                            
                // set item in sessionAttributes
                setItem(handlerInput,item);
                speakOutput += "¿Quieres usar ahora " + item.definedString +  "? "
                setQuestion(handlerInput,'QuieresUsarItem')
            }
        }
        else {
             speakOutput += itemName + " no está en la habitación";
        }
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
}


/*
    WhatIsInTheInventoryIntentHandler
    Tells the player what's in the inventory
*/
const WhatIsInTheInventoryIntentHandler = {
    
     canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhatIsInTheInventoryIntent';
    },
    
    handle(handlerInput) {
        
        const attributesManager = handlerInput.attributesManager;
        const sessionAttributes = attributesManager.getSessionAttributes()
        
        // get inventory
        const inventory = sessionAttributes.gamestate.inventory
        
        var speakOutput = "";
        
        // inventory empty or does not exist
        if (inventory === undefined || inventory.length === 0) {
            speakOutput += strings.EMPTY_INVENTORY_MESSAGE
        }
        
        // if not empty, format output with , . y
        else {
            
        speakOutput += strings.NON_EMPTY_INVENTORY_MESSAGE
        
          inventory.forEach((item, index) => {
              speakOutput += item.undefinedString ;
            
              if (index === inventory.length - 2){
                speakOutput += " y "
              }
              else if (index === inventory.length - 1){
                speakOutput += ". "
              }
              else {
                speakOutput += ", "
              }
            });
        }
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
}

/*
    HelpIntentHandler
    Outputs a message with help
*/
const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speakOutput = strings.HELP_MESSAGE
        const repromptOutput = strings.HELP_REPROMPT

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(repromptOutput)
            .getResponse();
    }
};


/*
    CancelAndStopIntentHandler
    Ends the game (exits the skill)
*/
const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = strings.STOP_MESSAGE;
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};


const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse();
    }
};

// The intent reflector is used for interaction model testing and debugging.
// It will simply repeat the intent the user said. You can create custom handlers
// for your intents by defining them above, then also adding them to the request
// handler chain below.
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `You just triggered ${intentName}, the sessionAttributes were ${JSON.stringify(handlerInput.attributesManager.getSessionAttributes())}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

// Generic error handling to capture any syntax or routing errors. If you receive an error
// stating the request handler chain is not found, you have not implemented a handler for
// the intent being invoked or included it in the skill builder below.
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        console.log(`~~~~ Error handled: ${error.stack}`);
        const speakOutput = strings.ERROR_MESSAGE

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};


/*
    LoadDataInterceptor
    Loads the persistentAttributes as sessionAttributes whenever a new session is opened
*/
const LoadDataInterceptor = {
    
    async process(handlerInput) {
        
        // if its a new session
        if (Alexa.isNewSession(handlerInput.requestEnvelope)) {
            
            // load persistentAttributes
            // there may be no persistentAttributes if it's a new user
            const attributesManager = handlerInput.attributesManager;
            const sessionAttributes = await attributesManager.getPersistentAttributes() || {};
            const hasPlayedBefore = sessionAttributes.hasOwnProperty('hasPlayedBefore') ? sessionAttributes.hasPlayedBefore : false;
            
            // set questionAsked as null
            sessionAttributes.questionAsked = null;
            
            // set hasPlayedBefore (can't be undefined even if it's a new player)
            sessionAttributes.hasPlayedBefore = hasPlayedBefore;
            
            
            const fetchedROOMS = await sync.fetchRooms();
            sessionAttributes.ROOMS = fetchedROOMS;
            
            attributesManager.setSessionAttributes(sessionAttributes);
            
        }
    }
    
};


/*
    SetGamestateInterceptor
    Saves the gamestate whenever the users changes it
*/
const SetGamestateInterceptor = {
    async process(handlerInput) {
        
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        const hasChangedGamestate = sessionAttributes.hasOwnProperty('hasChangedGamestate') ? sessionAttributes.hasChangedGamestate : false;

        if(hasChangedGamestate){
            var response = await sync.saveGamestate(handlerInput)
        }
    }
};

/*
    GetGamestateInterceptor
    Gets the gamestate before handling the request
*/
const GetGamestateInterceptor = {
    async process(handlerInput) {
        
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        
        
        const gamestate = await sync.fetchGamestate();
        sessionAttributes.hasChangedGamestate = false;
        
        sessionAttributes.gamestate = gamestate;
        handlerInput.attributesManager.setSessionAttributes(sessionAttributes);
    }
};


/*
    ClearQuestionInterceptor
    If alexa hasn't asked yes or no, removes the questionAsked in sessionAttributes, to avoid mishandlings
*/
const ClearQuestionInterceptor = {
    
    async process(handlerInput) {
        
        // if the Intent requested can't ask yes or no,
        // sets the questionAsked to null
        if (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest' && 
            !CanAskYesNo(Alexa.getIntentName(handlerInput.requestEnvelope))) {
           setQuestion(handlerInput,null)
        }
    }
    
};


// The SkillBuilder acts as the entry point for your skill, routing all request and response
// payloads to the handlers above. Make sure any new handlers or interceptors you've
// defined are included below. The order matters - they're processed top to bottom.
exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        NewPlayerStartIntentHandler,
        NotNewPlayerStartIntentHandler,
        InstructionsIntentHandler,
        GoToIntentHandler,
        WhereAmIIntentHandler,
        WhereCanIGoIntentHandler,
        RoomDescriptionIntentHandler,
        CheckItemIntentHandler,
        WhatIsInTheInventoryIntentHandler,
        YesIntentHandler,
        NoIntentHandler,
        DevicesCheckIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler, // make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers
    )
    .addRequestInterceptors(
        LoadDataInterceptor,
        GetGamestateInterceptor,
        ClearQuestionInterceptor,
    )
    .addResponseInterceptors(
        SetGamestateInterceptor,
    )
    .addErrorHandlers(
        ErrorHandler,
    )
    .withPersistenceAdapter(
        new persistenceAdapter.S3PersistenceAdapter({bucketName:process.env.S3_PERSISTENCE_BUCKET})
    )
    .lambda();
    
    
    
    
const strings = {
    SKILL_NAME: 'Escapa del planeta',
    OPEN_MESSAGE: 'Hola, has abierto la skill Escapa del Planeta. Cuando quieras comenzar el juego, dímelo.',
    HELP_MESSAGE: 'Puedes pedirme comenzar el juego o cerrarlo. ¿Cómo puedo ayudarte?',
    HELP_REPROMPT: '¿Cómo puedo ayudarte?',
    ERROR_MESSAGE: 'No he entendido lo que me has pedido. Prueba a repetirlo.',
    YES_NO_ERROR_MESSAGE: 'Creo que no te había hecho ninguna pregunta. Prueba a decirlo de otra forma',
    STOP_MESSAGE: '¡Hasta luego!',
    FIRST_TIME_START_MESSAGE: 'Parece que es la primera vez que abres la skill. Vamos a hacer un test para comprobar que funcionan todos los dispositivos. ' +
        'Tienes que leer el código QR que aparece en pantalla. Luego tienes que realizar al menos un click, doble click y pulsación larga del botón.',
    FIRST_TIME_REPROMPT_MESSAGE:'Tenemos que realizar una prueba de los dispositivos. Tienes que leer el código QR que aparece en pantalla.' +
        ' Luego tienes que realizar al menos un click, doble click y pulsación larga del botón' ,
    DEFAULT_START_MESSAGE: 'Bienvenido de nuevo a Escapa del Planeta.',
    INSTRUCTIONS_MESSAGE: 'Si quieres ir a algún sitio, di: ir a lugar. Si quieres examinar un objeto, di: examinar objeto o agarrar objeto. '
    + 'Tienes un inventario en el que puedes almacenar los objetos que encuentres, por lo que si quieres guardar un objeto simplemente di: guardar objeto. '+
    'En cualquier momento puedes pedirme ayuda diciendo: Necesito ayuda . ¿Te ha quedado claro? ',
    RELEVANT_EVENTS_MESSAGE: 'Estamos en el año 2199. Se ha producido un accidente durante la exploración del planeta XP-2917. ' +
    ' La vida de los integrantes de la Nave de Exploración Eternity está en peligro. Están en coma, en las cápsulas de regeneración de la nave.',
    GO_TO_OK_MESSAGE : 'Ahora estás en ',
    GO_TO_ERROR_MESSAGE: 'No puedes ir ',
    YOU_ARE_ALREADY_THERE_MESSAGE: 'Ya estás en ',
    ROOM_NOT_FOUND_MESSAGE: 'No he entendido adonde quieres ir. Prueba a repetirlo.  ',
    CAN_GO_TO_MESSAGE: 'Los lugares a los que puedes ir desde donde estás son: ',
    WHERE_IS_MESSAGE: 'Estás en ',
    EMPTY_INVENTORY_MESSAGE: 'Todavía no has guardado nada en el inventario. ',
    NON_EMPTY_INVENTORY_MESSAGE: 'En el inventario hay '
};


/*
const ROOMS = {
    
    INITIAL_ROOM: {
                name: 'habitación inicial', 
                string:'la habitación inicial', 
                doors: ['purificador'],
                locked: false
            },
            
    PURIFYER:{  
                name: 'purificador', 
                string:'el purificador', 
                doors: ['habitación inicial'],
                locked: false
            }
    
}
*/

const IntentsCanAskYesNo = ['AMAZON.YesIntent', 'AMAZON.NoIntent', 'InstructionsIntent', 'CheckItemIntent']
